require "rspec"
require 'doctor.rb'

describe "Doctor" do

  doctor = Doctor.new
  context "attributes of class doctor" do
    it "Doctor should have a speciality" do
      doctor.speciality = "pathologist"
      doctor.speciality.should == "pathologist"
    end
  end

    describe "methods of class doctor" do
      it "should register a new doctor to the system" do
      doctor.stub!(:add_doctor).with(1,2, "John", "James", "27 Cherry Street", "12345678910", "pathologist",  "34m43")
      doctor.add_doctor(1,2, "John", "James", "27 Cherry Street", "12345678910", "pathologist",  "34m43")

      file = mock('file')
      File.stub!(:open).with("filename", "privilege").and_yield(file)
      File.stub!(:write).with(1,2, "John", "James", "27 Cherry Street", "12345678910", "pathologist",  "34m43").and_return("1,2,John,James,27Cherry Street,12345678910,pathologist,34m43")
      File.write(1,2, "John", "James", "27 Cherry Street", "12345678910", "pathologist",  "34m43") == "1,2,John,James,27Cherry Street,12345678910,pathologist,34m43"
      end

      it "should register a new doctor to the system" do
        doctor.add_doctor(1,2, "John", "James", "27 Cherry Street", "12345678910", "pathologist",  "34m43")
        file = File.open("../csv/doctor.csv","r")
        file.each {|line|
         if (line.to_s == "1,2,John,James,27 Cherry Street,12345678910,pathologist,34m43")
               return true
         end
        }
      end
    end

end