require "rspec"
require '../lib/admin.rb'
require "../lib/doctor.rb"
require "../lib/receptionist.rb"

describe "Administrator" do

  admin = Admin.new
  let(:doctor){mock('Doctor')}
  let(:receptionist){mock('Receptionist')}

  context "the admin should be able to register new doctors or receptionist in the system" do
    it "defining add_doctor method and assign privileges" do

      id = doctor.stub!(:id_generator).and_return(1)
      doctor.stub!(:add_doctor).with(id,2, "John", "James", "27 Cherry Street", "12345678910", "pathologist",  "34m43")
      doctor.stub!(:set_privileges).with(id, "5000", "d")
      doctor.add_doctor(id,2, "John", "James", "27 Cherry Street", "12345678910", "pathologist",  "34m43")
      doctor.set_privileges(id, "5000", "d")
    end

    it "defining add_receptionist method and assign privileges" do

      id = receptionist.stub!(:id_generator).and_return(1)
      receptionist.stub!(:add_receptionist).with(id, "Marina", "Jacobson", "22 Mambo Street", "0123456789", "34m43")
      receptionist.stub!(:set_privileges).with(id, "5000", "r")
      receptionist.add_receptionist(id, "Marina", "Jacobson", "22 Mambo Street", "0123456789", "34m43")
      receptionist.set_privileges(id, "5000", "r")
    end
  end



   describe "register doctor and receptionists" do
       it "adding a doctor to the records of the system" do
            admin.set_privileges(1, "5000", "d")
            admin.add_receptionist(1, "Marina", "Jacobson", "22 Mambo Street", "0123456789","34m43")
     end
   end


  #
  #
  #
  #it "Admin should be able to add a new receptionist by using the addReceptionist method and assign privileges" do
  #
  #
  #  admin.addReceptionist("554655464","Anna", "Jacobs", "Normandy 3", "2332332333","rec8898")
  #  #admin.searchByName("../csv/receptionist.csv","Anna").should ==["nil,554655464,Anna,Jacobs,Normandy 3,2332332333,rec8898"]
  #end
  #
  #
  #
  #it "Admin should be able to add a new doctor by using the addDoctor method and assign privileges" do
  #  admin = Admin.new
  #  admin.addDoctor("123456","Onisiforos", "Onoufriou", "Berry 3", "21235","cardiologist","rec8412")
  #end
end