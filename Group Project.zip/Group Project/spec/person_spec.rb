require "rspec"
require "person.rb"
require 'csv'

describe "Person" do
  patient_file = "../csv/patient.csv"

  person = Person.new


  context "initializing 2 most important attributes" do
   it "person should have a first name" do

     person.first_name = "John"
     person_fname = person.first_name
     person_fname.should == "John"
   end

   it "person should have an id number" do

     person.id_number = "886677"
     person_fname = person.id_number
     person_fname.should == "886677"
   end


   it "person.id_generator should return a unique id number" do

     person.stub!(:id_generator).and_return(5000)
     person.id_generator.should == 5000

   end

   it "person.set_privileges should get (unique id number, password, privileges) and add a new user to the login list" do

       person.stub!(:set_privileges).with(1, "5000", "d")
       person.set_privileges(1, "5000", "d")
       file = mock('file')
       File.stub!(:open).with("filename", "privilege").and_yield(file)
       File.stub!(:write).with(1, "5000", "d").and_return("1,5000,d")
       File.write(1,"5000","d") == "1,5000,d"

   end

   it "person.id_generator should generate unique id number > 0" do
      person.id_generator.should > 0

   end

 end
end



  #
  # it "Person should have a last name" do
  #   person1 = Person.new
  #   person1.lastName = "aPersonLastName"
  #   personlname = person1.lastName
  #
  #   personlname.should == "aPersonLastName"
  #   end
  #
  # it "Person should have a id" do
  #   person1 = Person.new
  #   person1.id = "1"
  #   personid = person1.id
  #
  #   personid.should == "1"
  # end
  #
  # it "Person should have an username" do
  #   person1 = Person.new
  #   person1.userName = "aUserName"
  #   personuserName = person1.userName
  #
  #   personuserName.should == "aUserName"
  # end
  #
  # it "Person should have a password" do
  #   person1 = Person.new
  #   person1.password = "pass"
  #   personpassword = person1.password
  #
  #   personpassword.should == "pass"
  # end
  #
  # it "Person should have an address" do
  #   person1 = Person.new
  #   person1.address = "Manchester"
  #   personaddress = person1.address
  #
  #   personaddress.should == "Manchester"
  # end
  #
  # it "Person should have a phone" do
  #   person1 = Person.new
  #   person1.phoneNumber = "123456789"
  #   personphoneNumber = person1.phoneNumber
  #
  #   personphoneNumber.should == "123456789"
  # end
  #
  # it "generated_id  should have default value" do
  #   person1 = Person.new()
  #   person1.id.should == person1.idGenerator()
  # end

  #it "Receptionist should be able to search for a patient by id" do
  #  result = person.searchByID("5058",patient_file)
  #  result.should_not == nil
  #end
  #
  #it "Receptionist should be able to search for patients by name" do
  #  result = person.searchByName( patient_file,"sandra")
  #  result.should_not == nil


